package br.senai.jandira.sp.Model;

public class Book {

    public String titulo, autor, isbn, genero;

}
