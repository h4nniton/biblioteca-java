package br.senai.jandira.sp.Model;

public class Consultar {

    Book book = new Book();
}
