package br.senai.jandira.sp.Model;

public class User {

    public String nome, numero, endereco, email, telefone;
}
