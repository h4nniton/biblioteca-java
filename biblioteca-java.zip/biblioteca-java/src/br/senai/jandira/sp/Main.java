package br.senai.jandira.sp;

import br.senai.jandira.sp.Model.Menu;

public class Main {
    public static void main(String[] args) {

        Menu menu = new Menu();
        menu.Menu();

    }
}